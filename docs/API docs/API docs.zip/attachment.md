# 附件管理 接口文档

## 接口概述

`attachment` 控制器用于管理附件文件，支持文件的上传、下载、查询、删除等操作。支持两种存储驱动（**本地存储 local**、**腾讯云 COS**），包含秒传去重、文件安全校验等功能。

### 接口类型说明

| 接口类型 | 说明 |
| :--- | :--- |
| **基础接口** | 支持15个基础接口：one、all、rand、count、sum、min、max、column、remove、delete、clear、restore、save、create、update |
| **特殊接口** | 文件上传、文件类型检查、获取我的附件列表、获取表情列表、获取当前存储方式 |

> **接口规范说明**：`save` 接口为内部兼容接口，无ID时新增，有ID时更新。**推荐外部调用使用 `create`（新增）和 `update`（更新）**，语义更清晰。

### 存储驱动说明

| 驱动标识 | 说明 |
| :--- | :--- |
| **local** | 本地存储，写入 `public/<local.path>/<dir_rule>/<file_rule>.<ext>`（`local.path` 默认 `storage`，`dir_rule` 默认 `{Y}-{m}/{d}`） |
| **cos** | 腾讯云 COS 存储（对象键同样由 `cos.path` + `dir_rule` + `file_rule` 组成） |

> `dir_rule`（目录命名规则）与 `file_rule`（文件命名规则）可在后台「系统设置 → 存储」里自定义，
> 占位符（`{Y}` / `{m}` / `{d}` / `{timestamp}` / `{uniqid}` / `{md5}` / `{md5-16}` /
> `{str-random-16}` / `{str-random-10}` / `{filename}` / `{uid}`）与默认值、
> 清洗规则见「toml 配置接口文档 → 特殊说明 5. 上传命名规则」。

**本地存储（local）**

- 文件落在项目的 `public` 目录（站点静态资源根目录），
  数据库里的 `save_path` 是 `/storage/2026-09/26/17588888881a2b3c4d5e.jpg` 形式
  （前缀 + 目录规则 + 文件规则 + 扩展名）；
- `full_url = local.domain + save_path`：`local.domain` **留空**时是相对路径（`/storage/xxx`，跟随站点域名），
  需要 CDN 时填 `https://cdn.example.com`（此时是 `https://cdn.example.com/storage/xxx`）；
  ⚠️ 不要填成与 `local.path` 相同的值（例如都填 `storage`），否则会拼出 `storage/storage/xxx` 这种无效地址；
- 删除是幂等的：文件已不存在也算删除成功，便于回收站重复清理。

**腾讯云 COS（cos）**

- **桶名**：`bucket` 可填裸桶名（`inis-cos`，SDK 自动补 `-<app_id>`），也可填控制台复制的全名
  （`inis-cos-1250000000`，不会再重复拼 app_id）；`region` 留空按 `ap-guangzhou`；
- **访问域名**：未配置 `cos.domain` 时使用 `https://<bucket>-<app_id>.cos.<region>.myqcloud.com`，
  上传写入的 `{{cos}}` 模板与查询时的展开口径一致（换自定义域名只需改配置，历史地址自动跟随）；
- **上传命名**：对象键 = `cos.path` 前缀 + `dir_rule` 目录规则 + `file_rule` 文件规则 + 扩展名
  （如 `inis/2026/09/26/20260926-1a2b3c4d5e.jpg`），规则与占位符见
  「toml 配置接口文档 → 特殊说明 5. 上传命名规则」；
- **上传**：对象键取消前导斜杠（历史上前缀为空会生成 `/2026-09/…` 这种键），
  上传时对单个对象设置 `x-cos-acl: public-read`，桶不存在时才以「公共读私有写」创建（删除操作不会建桶）；
- **删除**：单个对象用 `DELETE Object`（对象不存在返回 404 视为成功）；
  批量用 `DELETE Multiple Objects`（Quiet 模式，单请求最多 1000 个对象，代码按 500 分批）；
  若响应里存在失败对象（`ObjectDeleteMultiResult.Errors`），会返回错误，调用方据此**保留对应记录**
  （避免「以为删掉了、其实还在」）。CAM 授权需要 `cos:DeleteObject`（匿名批删还需 `cos:DeleteMultipleObjects`）。

### 业务类型说明

| 类型标识 | 说明 |
| :--- | :--- |
| **article** | 文章配图 |
| **comment** | 评论图片 |
| **user_avatar** | 用户头像 |
| **其他** | 可自定义扩展其他业务类型 |

---

## 状态码规范

| 状态码 | 说明 | 使用场景 |
| :--- | :--- | :--- |
| **200** | 请求成功 | 获取数据成功、操作成功 |
| **201** | 创建成功 | 新增数据成功 |
| **204** | 无内容 | 查询无数据、无可操作数据 |
| **400** | 请求错误 | 参数校验失败、操作失败 |
| **401** | 未授权 | 用户未登录 |
| **403** | 无权限 | 无操作权限 |
| **207** | 部分成功 | 批量操作部分成功、部分失败 |
| **405** | 方法不允许 | 请求方法错误或方法名错误 |
| **500** | 服务器错误 | 系统内部错误 |

### 批量操作响应格式

涉及批量操作的接口（`remove`、`delete`）采用部分成功模式，返回统一格式：

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `success_ids` | array | 操作成功的ID列表 |
| `failed_ids` | array | 操作失败的ID列表 |
| `errors` | object | 失败原因映射，key为ID，value为错误信息 |

**状态码说明**：
- `200`：全部成功
- `207`：部分成功，部分失败
- `400`：全部失败

---

## 接口列表

### 1. 获取单个附件 [one]

- **接口类型**: 基础接口 / 获取指定
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/one`
- **说明**: 根据条件获取单个附件

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `id` | int | 否 | 附件ID |
| `uuid` | string | 否 | 附件UUID（优先使用） |
| `field` | string | 否 | 返回字段，逗号分隔 |
| `where` | json | 否 | 条件查询 |
| `withTrashed` | bool | 否 | 是否包含已删除数据 |
| `onlyTrashed` | bool | 否 | 是否只查询已删除数据 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": {
        "id": 1,
        "uuid": "xxx-xxx-xxx",
        "original_name": "test.jpg",
        "full_url": "https://cdn.example.com/storage/2024-01/01/xxx.jpg",
        "file_size": 102400,
        "mime_type": "image/jpeg",
        "file_ext": "jpg",
        "create_time": 1699900000
    }
}
```

### 2. 获取所有附件 [all]

- **接口类型**: 基础接口 / 获取全部
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/all`
- **说明**: 分页获取附件列表

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `page` | int | 否 | 页码，默认1 |
| `limit` | int | 否 | 每页数量 |
| `order` | string | 否 | 排序字段，默认 `create_time desc` |
| `field` | string | 否 | 返回字段，逗号分隔 |
| `where` | json | 否 | 条件查询 |
| `like` | json | 否 | 模糊查询 |
| `target_type` | string | 否 | 业务类型筛选 |
| `target_id` | int | 否 | 业务ID筛选 |
| `storage_driver` | string | 否 | 存储驱动筛选 |
| `file_ext` | string | 否 | 文件扩展名筛选 |
| `withTrashed` | bool | 否 | 是否包含已删除数据 |
| `onlyTrashed` | bool | 否 | 是否只查询已删除数据 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": {
        "data": [...],
        "count": 100,
        "page": 10
    }
}
```

**权限说明**:
- 管理员：可查看所有附件
- 普通用户：仅查看自己的附件

**补充字段（仅本接口）**:
- 每行会额外返回 `uploader_account`（上传者账号）与 `uploader_name`（上传者昵称，
  昵称为空时回退账号，账号也没有时为「用户 #id」），由后端按 `uploader_id` 批量查询补齐，
  后台附件列表直接展示昵称而不是数字 ID；
- 传了 `field` 裁剪字段时，只有 `field` 里显式包含 `uploader` 才会补这两个字段；
- 这两个字段只在响应时补，不写入缓存，用户改昵称后立即生效。

### 3. 随机获取附件 [rand]

- **接口类型**: 基础接口 / 随机获取
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/rand`
- **说明**: 随机获取指定数量的附件

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `limit` | int | 否 | 返回数量 |
| `except` | string | 否 | 排除的ID，逗号分隔 |
| `field` | string | 否 | 返回字段 |
| `onlyTrashed` | bool | 否 | 是否只查询已删除数据 |
| `withTrashed` | bool | 否 | 是否包含已删除数据 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "好的！",
    "data": [...]
}
```

### 4. 查询数量 [count]

- **接口类型**: 基础接口 / 查询数量
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/count`
- **说明**: 查询附件数量

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `where` | json | 否 | 条件查询 |
| `target_type` | string | 否 | 业务类型筛选 |
| `target_id` | int | 否 | 业务ID筛选 |
| `withTrashed` | bool | 否 | 是否包含已删除数据 |
| `onlyTrashed` | bool | 否 | 是否只查询已删除数据 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "查询成功！",
    "data": 100
}
```

### 5. 求和 [sum]

- **接口类型**: 基础接口 / 求和
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/sum`
- **说明**: 对指定字段求和（如文件大小总和）

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `field` | string | **是** | 求和字段 |
| `where` | json | 否 | 条件查询 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": {
        "file_size": 104857600
    }
}
```

### 6. 最小值 [min]

- **接口类型**: 基础接口 / 最小值
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/min`
- **说明**: 获取指定字段最小值

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `field` | string | **是** | 字段名 |
| `where` | json | 否 | 条件查询 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": {
        "file_size": 1024
    }
}
```

### 7. 最大值 [max]

- **接口类型**: 基础接口 / 最大值
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/max`
- **说明**: 获取指定字段最大值

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `field` | string | **是** | 字段名 |
| `where` | json | 否 | 条件查询 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": {
        "file_size": 52428800
    }
}
```

### 8. 查询列 [column]

- **接口类型**: 基础接口 / 查询列
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/column`
- **说明**: 获取指定字段列表

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `field` | string | **是** | 字段名 |
| `where` | json | 否 | 条件查询 |
| `or` | json | 否 | 或条件查询 |
| `like` | json | 否 | 模糊查询 |
| `not` | json | 否 | 排除条件 |
| `null` | string | 否 | 空值查询 |
| `notNull` | string | 否 | 非空查询 |
| `order` | string | 否 | 排序字段 |
| `ids` | string | 否 | 指定ID列表 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "数据请求成功！",
    "data": ["test1.jpg", "test2.jpg"]
}
```

**安全说明**:
- 普通用户调用时必须携带筛选条件（where/or/like/not/null/notNull/ids），否则返回400错误
- 普通用户查询结果最多返回100条记录，防止全表查询导致内存溢出

### 9. 获取我的附件 [list]

- **接口类型**: 特殊接口
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/list`
- **说明**: 获取当前用户上传的附件列表

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `page` | int | 否 | 页码，默认1 |
| `limit` | int | 否 | 每页数量 |
| `order` | string | 否 | 排序字段，默认 `create_time desc` |
| `field` | string | 否 | 返回字段，逗号分隔 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "查询成功！",
    "data": {
        "data": [...],
        "count": 10,
        "page": 1
    }
}
```

**权限说明**: 需要用户登录

### 10. 获取表情列表 [emoji]

- **接口类型**: 特殊接口
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/emoji`
- **说明**: 自动扫描 `public/assets/emoji` 目录及其子目录，返回所有表情分类与表情文件列表。前端可直接使用返回的 `url` 字段渲染表情图片。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `category` | string | 否 | 指定分类名称，仅返回该分类的表情。不传则返回全部分类。例如 `qq`、`bilibili`、`tiktok` |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "查询成功！",
    "data": {
        "categories": [
            {
                "name": "bilibili",
                "count": 48,
                "items": [
                    {
                        "name": "aggrieved",
                        "file": "aggrieved.webp",
                        "url": "/assets/emoji/bilibili/aggrieved.webp",
                        "ext": ".webp",
                        "size": 12345
                    },
                    {
                        "name": "angry",
                        "file": "angry.webp",
                        "url": "/assets/emoji/bilibili/angry.webp",
                        "ext": ".webp",
                        "size": 12345
                    }
                ]
            },
            {
                "name": "qq",
                "count": 88,
                "items": [
                    {
                        "name": "OK",
                        "file": "OK.gif",
                        "url": "/assets/emoji/qq/OK.gif",
                        "ext": ".gif",
                        "size": 12345
                    }
                ]
            },
            {
                "name": "tiktok",
                "count": 87,
                "items": [
                    {
                        "name": "666",
                        "file": "666.png",
                        "url": "/assets/emoji/tiktok/666.png",
                        "ext": ".png",
                        "size": 12345
                    }
                ]
            }
        ],
        "total": 223
    }
}
```

**返回字段说明**:

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `categories` | array | 表情分类列表 |
| `categories[].name` | string | 分类名称（即 `public/assets/emoji` 下的子目录名，如 `bilibili`、`qq`、`tiktok`） |
| `categories[].count` | int | 该分类下表情文件数量 |
| `categories[].items` | array | 表情文件列表 |
| `categories[].items[].name` | string | 表情名称（文件名不含扩展名） |
| `categories[].items[].file` | string | 表情文件名（含扩展名） |
| `categories[].items[].url` | string | 表情访问URL路径，可直接用于 `<img :src="url">` |
| `categories[].items[].ext` | string | 文件扩展名（小写，如 `.webp`、`.gif`、`.png`） |
| `categories[].items[].size` | int | 文件大小（字节） |
| `total` | int | 所有分类表情文件总数 |

**按分类查询示例**:

```http
GET /api/attachment/emoji?category=qq
```

返回结果仅包含 `qq` 分类：

```json
{
    "code": 200,
    "msg": "查询成功！",
    "data": {
        "categories": [
            {
                "name": "qq",
                "count": 88,
                "items": [...]
            }
        ],
        "total": 88
    }
}
```

**支持的文件类型**: `.png`、`.jpg`、`.jpeg`、`.gif`、`.webp`、`.svg`、`.bmp`

**目录结构说明**:

```text
public/assets/emoji/
├── bilibili/       # B站表情包（.webp）
│   ├── aggrieved.webp
│   ├── angry.webp
│   └── ...
├── qq/             # QQ表情包（.gif）
│   ├── OK.gif
│   ├── aini.gif
│   └── ...
└── tiktok/         # 抖音表情包（.png）
    ├── 666.png
    ├── OK.png
    └── ...
```

> 新增表情时，只需在 `public/assets/emoji/` 下新建分类目录并放入图片，接口会自动识别，无需重启或修改代码。

**权限说明**: 公开接口，无需登录

**前端调用示例**:

```javascript
// 获取全部表情
const res = await axios.get('/api/attachment/emoji')
const categories = res.data.data.categories

// 获取指定分类表情
const res = await axios.get('/api/attachment/emoji', {
  params: { category: 'qq' }
})

// 渲染表情
categories.forEach(category => {
  category.items.forEach(emoji => {
    // <img :src="emoji.url" :alt="emoji.name" />
  })
})
```

**错误响应** (500):

```json
{
    "code": 500,
    "msg": "读取表情失败: open public/assets/emoji: no such file or directory",
    "data": null
}
```

### 11. 获取当前存储方式 [storage]

- **接口类型**: 特殊接口
- **请求方式**: `GET`
- **请求地址**: `/api/attachment/storage`
- **说明**: 返回配置（`config/storage.toml` 的 `default`）当前实际生效的存储驱动，供后台「附件管理」概览在标题旁展示。

**请求参数**: 无

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "查询成功！",
    "data": {
        "driver": "cos",
        "name": "腾讯云 COS"
    }
}
```

**返回字段说明**:

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `driver` | string | 驱动标识：`local`（本地存储）/ `cos`（腾讯云 COS）；未知值一律回退 `local` |
| `name` | string | 驱动展示名（与「系统设置 → 存储」的选项文案一致） |

> **与附件记录里的 `storage_driver` 的区别**：`storage_driver` 是**每个附件上传时**用的驱动，
> 历史数据里可能残留已下线的 `oss` / `kodo`（删除时会回退按本地存储处理）；
> 本接口返回的是当前配置，即「新上传的文件会存到哪儿」。

**权限说明**: 公开接口，无需登录

---

### 12. 保存附件 [save]

- **接口类型**: 基础接口 / 保存数据
- **请求方式**: `POST`
- **请求地址**: `/api/attachment/save`
- **说明**: 保存附件（新增或更新）

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `id` | int | 否 | 附件ID，为空时新增 |
| `uuid` | string | 否 | 附件UUID |
| `original_name` | string | 否 | 原始文件名 |
| `target_type` | string | 否 | 业务类型 |
| `target_id` | int | 否 | 业务ID |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "创建成功！",
    "data": {
        "id": 1,
        "uuid": "xxx-xxx-xxx"
    }
}
```

### 13. 创建附件 [create]

- **接口类型**: 基础接口 / 添加数据
- **请求方式**: `POST`
- **请求地址**: `/api/attachment/create`
- **说明**: 新增附件记录

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `original_name` | string | 否 | 原始文件名 |
| `target_type` | string | 否 | 业务类型 |
| `target_id` | int | 否 | 业务ID |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "创建成功！",
    "data": {
        "id": 1,
        "uuid": "xxx-xxx-xxx"
    }
}
```

**权限说明**: 需要用户登录

### 14. 文件上传 [batch]

- **接口类型**: 特殊接口
- **请求方式**: `POST`
- **请求地址**: `/api/attachment/batch`
- **说明**: 文件上传接口，支持单文件和多文件上传，支持秒传去重

**Content-Type**: `multipart/form-data`

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `file` | file | 否 | 单个上传文件（与files二选一） |
| `files` | file[] | 否 | 上传的文件数组，数量上限由配置 `concurrent_limit` 决定（与file二选一） |
| `target_type` | string | 否 | 业务类型 |
| `target_id` | int | 否 | 业务ID |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "上传完成！",
    "data": {
        "results": [
            {
                "id": 1,
                "uuid": "xxx",
                "original_name": "a.jpg",
                "full_url": "...",
                "file_size": 102400,
                "status": "success"
            },
            {
                "original_name": "b.jpg",
                "full_url": "...",
                "status": "exist"
            }
        ],
        "success": 2,
        "fail": 0
    }
}
```

**结果状态说明**:
- `success`：上传成功
- `exist`：文件已存在（秒传）
- `fail`：上传失败，包含错误信息

**失败响应** (400):

```json
{
    "code": 400,
    "msg": "所有文件上传失败！",
    "data": {
        "results": [
            {
                "original_name": "invalid.exe",
                "status": "fail",
                "error": "不允许上传该类型的文件！"
            }
        ],
        "success": 0,
        "fail": 1
    }
}
```

**部分成功响应** (207):

```json
{
    "code": 207,
    "msg": "部分文件上传成功！",
    "data": {
        "results": [
            {
                "id": 1,
                "uuid": "xxx",
                "original_name": "valid.jpg",
                "full_url": "...",
                "file_size": 102400,
                "status": "success"
            },
            {
                "original_name": "invalid.exe",
                "status": "fail",
                "error": "不允许上传该类型的文件！"
            }
        ],
        "success": 1,
        "fail": 1
    }
}
```

**权限说明**: 需要用户登录

### 15. 检查文件类型 [checktype]

- **接口类型**: 特殊接口
- **请求方式**: `POST`
- **请求地址**: `/api/attachment/checktype`（服务端会把 `:method` 转小写，写 `checkType` 也能命中，但建议统一小写）
- **说明**: 检查文件类型是否允许上传，支持批量检查

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `file_names` | string[] | 是 | 文件名列表，如 ["test.jpg", "document.pdf"] |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "检查完成！",
    "data": {
        "results": [
            {
                "file_name": "test.jpg",
                "file_ext": "jpg",
                "is_allowed": true,
                "message": "文件类型允许上传"
            },
            {
                "file_name": "document.pdf",
                "file_ext": "pdf",
                "is_allowed": true,
                "message": "文件类型允许上传"
            },
            {
                "file_name": "malware.exe",
                "file_ext": "exe",
                "is_allowed": false,
                "message": "不允许上传该类型的文件"
            }
        ],
        "allowed_count": 2,
        "disallowed_count": 1,
        "allow_extensions": ["jpg", "png", "gif", "webp", "bmp", "svg", "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "zip", "rar", "7z", "txt", "md"],
        "max_file_size": 51200,
        "max_file_size_kb": 51200,
        "max_file_size_mb": 50
    }
}
```

**返回字段说明**:

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `results` | array | 文件检查结果列表 |
| `results[].file_name` | string | 文件名 |
| `results[].file_ext` | string | 文件扩展名 |
| `results[].is_allowed` | bool | 是否允许上传 |
| `results[].message` | string | 检查结果提示 |
| `allowed_count` | int | 允许上传的文件数量 |
| `disallowed_count` | int | 不允许上传的文件数量 |
| `allow_extensions` | array | 允许上传的文件扩展名列表 |
| `max_file_size` | int | 单个文件最大大小（KB） |
| `max_file_size_kb` | int | 单个文件最大大小（KB） |
| `max_file_size_mb` | float | 单个文件最大大小（MB） |

**权限说明**: 需要用户登录

---

### 16. 更新附件 [update]

- **接口类型**: 基础接口 / 修改数据
- **请求方式**: `PUT`
- **请求地址**: `/api/attachment/update`
- **说明**: 更新附件信息

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `id` | int | 否 | 附件ID |
| `uuid` | string | 否 | 附件UUID（优先使用） |
| `original_name` | string | 否 | 原始文件名 |
| `target_type` | string | 否 | 业务类型 |
| `target_id` | int | 否 | 业务ID |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "更新成功！",
    "data": {
        "id": 1,
        "uuid": "xxx-xxx-xxx"
    }
}
```

**权限说明**:
- 管理员可以更新所有附件
- 普通用户只能更新自己的附件

### 17. 恢复附件 [restore]

- **接口类型**: 基础接口 / 恢复数据
- **请求方式**: `PUT`
- **请求地址**: `/api/attachment/restore`
- **说明**: 从回收站恢复附件，恢复后附件可正常访问

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `ids` | string | **是** | 附件ID列表，逗号分隔 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "恢复成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [],
        "errors": {}
    }
}
```

**部分成功响应** (207):

```json
{
    "code": 207,
    "msg": "部分恢复成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [3],
        "errors": {
            "3": "无权恢复该附件或附件不存在"
        }
    }
}
```

**权限说明**:
- 管理员可以恢复所有附件
- 普通用户只能恢复自己的附件

---

### 18. 软删除附件 [remove]

- **接口类型**: 基础接口 / 软删除
- **请求方式**: `DELETE`
- **请求地址**: `/api/attachment/remove`
- **说明**: 将附件移入回收站，仅标记数据库记录，不会删除存储桶文件

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `ids` | string | **是** | 附件ID列表，逗号分隔 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "删除成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [],
        "errors": {}
    }
}
```

**部分成功响应** (207):

```json
{
    "code": 207,
    "msg": "部分删除成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [3],
        "errors": {
            "3": "无权删除该附件"
        }
    }
}
```

**权限说明**:
- 管理员可以删除所有附件
- 普通用户只能删除自己的附件

**特殊说明**: 软删除仅标记数据库记录，**不会删除存储桶文件**，支持通过`/api/attachment/restore`恢复。恢复后附件可正常访问。批量删除时采用部分成功模式，有权限的删除成功，无权限的返回失败信息。

### 19. 彻底删除附件 [delete]

- **接口类型**: 基础接口 / 彻底删除
- **请求方式**: `DELETE`
- **请求地址**: `/api/attachment/delete`
- **说明**: 永久删除附件，不可恢复，同时从存储删除物理文件

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `ids` | string | **是** | 附件ID列表，逗号分隔 |

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "删除成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [],
        "errors": {},
        "file_deleted": 2,
        "file_failed": 0
    }
}
```

**部分成功响应** (207):

```json
{
    "code": 207,
    "msg": "部分删除成功！",
    "data": {
        "success_ids": [1, 2],
        "failed_ids": [3],
        "errors": {
            "3": "存储文件删除失败，记录已保留（详见运行日志）"
        },
        "file_deleted": 2,
        "file_failed": 1
    }
}
```

**批量响应字段**:

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| `success_ids` | array | 已彻底删除（存储文件 + 数据库记录都已删除）的附件 ID |
| `failed_ids` | array | 未处理的附件 ID（不存在，或文件删除失败） |
| `errors` | object | ID → 失败原因 |
| `file_deleted` | int | 已成功从存储删除的文件数 |
| `file_failed` | int | 删除失败的文件数（失败会记入 `runtime` 日志） |

**权限说明**: 仅管理员可操作

**执行顺序与失败处理**: 先删存储文件、再删数据库记录。**文件删除失败的附件记录会保留**（不会出现「记录没了、文件还在」的孤儿文件），此时返回 207 并在 `errors` 中说明，修复存储配置后可重试。

**存储驱动**: 按附件记录的 `storage_driver` 字段选择驱动（local / cos），未记录驱动时用当前默认驱动。腾讯云 COS 按 **500 个/批**调用批量删除接口，本地存储逐个删除且「文件已不存在」视为成功（幂等）。

### 20. 清空回收站 [clear]

- **接口类型**: 基础接口 / 清空回收站
- **请求方式**: `DELETE`
- **请求地址**: `/api/attachment/clear`
- **说明**: 清空回收站中的附件，同时从存储删除物理文件

**请求参数**: 无

**成功响应** (200):

```json
{
    "code": 200,
    "msg": "清空成功！",
    "data": {
        "ids": [1, 2, 3],
        "kept_ids": [],
        "errors": {},
        "file_deleted": 3,
        "file_failed": 0
    }
}
```

**部分成功响应** (207):

```json
{
    "code": 207,
    "msg": "部分清空成功：部分记录的文件删除失败，已保留！",
    "data": {
        "ids": [1, 2],
        "kept_ids": [3],
        "errors": {
            "3": "存储文件删除失败，记录已保留（详见运行日志）"
        },
        "file_deleted": 2,
        "file_failed": 1
    }
}
```

**权限说明**: 仅管理员可操作

**执行顺序与失败处理**: 同样是**先删文件、再删记录**，文件删除失败的记录会留在回收站（`kept_ids`），修复存储后可再次清空；全部文件都删除失败时返回 400 且不删除任何记录。

**存储驱动**: 同「彻底删除附件」（见 19）：按 `storage_driver` 选择驱动，云存储 500 个/批，本地逐个删除且幂等。

---

## 特殊说明

### 1. 秒传去重机制
- 上传前计算文件MD5值
- 数据库中已存在相同MD5的文件时，直接返回已有记录
- 避免重复存储相同文件，节省存储空间

### 2. 文件安全校验
- **扩展名白名单**：仅允许配置的文件类型
- **文件内容校验**：根据扩展名验证文件头（Magic Bytes），防止改后缀上传恶意文件
  - 图片格式（jpg/png/gif/webp/bmp）：验证文件头标识
  - PDF：验证 `%PDF` 头部
  - Office 旧格式（doc/xls/ppt）：验证 OLE2 复合文档头部
  - Office 新格式（docx/xlsx/pptx）：验证 ZIP 头部标识
  - 压缩格式（zip/rar/7z）：验证文件头标识
  - SVG：验证 `<svg` 或 `<?xml` 头部，防止存储型 XSS 攻击
- **内容与扩展名不符时的处理**（QQ / 微信保存的二维码图、浏览器「另存为」的图片
  经常是「文件名 `.jpg`、内容其实是 PNG / WebP」）：
  - 真实类型**能按文件头判定**（jpg / png / gif / webp / bmp / pdf / rar / 7z）
    且该类型在允许列表里 → **按真实内容纠正扩展名**，照常上传成功，日志里记一条 `from → to`；
    存储对象与 `mime_type` 都用真实类型（如 `xxx.png`、`image/png`），
    `original_name` 仍是用户上传时的名字（便于对上号）；
  - 判定不了（doc/xls/ppt 同为 OLE2 头，docx/xlsx/pptx 与 zip 同为 PK 头）或真实类型不被允许
    → 返回 `文件内容与扩展名不匹配：内容的真实类型是 PNG 图片，请把后缀改成 .png 后再上传`，
    而不是一句没有信息量的「不匹配」
- **文件名安全**：使用 `filepath.Clean` + 正则过滤非法字符，防止路径遍历攻击
  - 过滤字符：`<>`:`/\|?*` 和控制字符（0x00-0x1F）
  - 移除 `../` 类路径穿越
- **SVG XSS 防护**：上传 SVG 时自动清洗 `<script>`、`<foreignObject>` 标签、`on*` 事件属性、`CDATA` 块、`javascript:`、`vbscript:` 协议
- **文件哈希算法**：使用 SHA-256 计算文件哈希，防止碰撞攻击

### 3. 并发上传限制
- 并发计数走缓存层的原子自增（`facade.Cache.Incr`）：`redis` 驱动下多实例共享，
  `file` / `ram` 驱动只在单实例内有效
- 缓存不可用时**降级为进程内计数器并放行**（不会因为缓存故障拒绝上传），同时打一条 warn 日志
- 计数 key 为 `attachment:upload_concurrent_counter`，最终键名前缀由 `cache.toml` 的 `redis.prefix` 决定
- key 仅首次创建时设置 5 分钟过期，防止持续上传场景下永不过期；释放时若 key 已过期则不再自减，避免留下负数

### 4. 查询安全
- **column 接口**：普通用户必须携带筛选条件（where/or/like/not/null/notNull/ids），最多返回100条记录
- **rand 接口**：使用 `ORDER BY RAND()` 避免全表 ID 查询，限制最多返回100条
- **聚合查询**（sum/min/max）：仅支持管理员操作，防止全表聚合拖垮数据库

### 5. 缓存策略
- 缓存设置 10 分钟过期时间，避免缓存永久堆积
- 异步删除缓存时添加 panic 捕获，防止协程崩溃

### 6. 秒传安全
- 秒传时校验文件上传者权限，非上传者且非管理员仅返回"文件已存在"提示，不暴露文件详情

### 7. 存储驱动切换
- 通过配置文件 `config/storage.toml` 配置默认存储驱动（default字段）
- 支持本地（local）与腾讯云 COS（cos）两种驱动
- **上传**：使用default配置的驱动存储新文件
- **删除**：根据附件记录的`storage_driver`字段自动选择对应的驱动删除物理文件
- **驱动独立性**：即使切换了默认驱动，历史附件仍能被正确管理（每个附件记录了自己的存储驱动）

### 9. 附件配置选项

所有配置在 `config/storage.toml` 的 `[attachment]` 段中设置：

| 配置项 | 类型 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- |
| `allow_extensions` | string | `jpg,png,gif,webp,bmp,svg,pdf,doc,docx,xls,xlsx,ppt,pptx,zip,rar,7z,txt,md` | 允许上传的文件类型，多个用逗号分隔（小写） |
| `max_file_size` | int | `51200` | 单个文件最大大小（KB），默认50MB |
| `concurrent_limit` | int | `5` | 并发上传限制（同时上传的最大文件数），使用互斥锁保证并发安全 |

**配置示例**:

```toml
[attachment]
allow_extensions = "jpg,png,gif,webp,pdf,doc,docx,xlsx"
max_file_size = 51200
concurrent_limit = 5
```

**配置说明**：
- `concurrent_limit = 5`：同时最多5个文件上传

**配置接口**：

附件配置可通过以下接口进行动态修改，无需重启服务：

| 接口 | 方法 | 说明 |
| :--- | :--- | :--- |
| `/api/toml/storage?name=attachment` | GET | 获取附件配置 |
| `/api/toml/storage-attachment` | PUT | 修改附件配置 |

**修改配置请求示例**:

```json
{
    "allow_extensions": "jpg,png,gif,webp",
    "max_file_size": 10240,
    "concurrent_limit": 5
}
```

**注意**：修改配置后会自动重新加载，立即生效。

### 6. 权限控制
- 普通用户：只能查看、上传、删除自己的附件
- 管理员：可管理所有附件，包括物理删除、清空回收站

### 7. 业务绑定
- 通过`target_type`和`target_id`实现与其他模块的关联
- 支持动态扩展业务类型

### 8. 缓存策略
- 所有查询接口均支持缓存
- 数据修改后会自动清除相关缓存

### 9. 错误处理
- 彻底删除（`delete`）与清空回收站（`clear`）会先删存储文件：**文件删除失败的记录保留**，
  不会出现「记录没了、存储桶里的文件还在」的孤儿文件
- 成功 / 失败的文件数在响应里给出（`file_deleted` / `file_failed`），失败详情记入运行日志
- 软删除（`remove`）只标记记录、不碰存储文件，属于回收站语义（可用 `restore` 还原）

### 10. 上传限制说明
- **并发上传限制**：同时进行的上传请求数不能超过 `concurrent_limit` 配置值；计数走缓存原子自增
  （redis 下多实例共享，缓存故障时降级为本地计数并放行）
- **批量上传**：批量上传时，会先检查总数是否超过限制和并发限制，再逐个处理
- **秒传文件**：秒传文件（已存在相同MD5）不计入上传数量限制，但会占用并发上传计数
- **错误提示**：超过限制时会返回对应的错误信息，如"并发上传数量已达上限（5个）！"
- **大文件与内存**：multipart 请求在参数中间件阶段就按流式解析，超过 8MB 的文件部分落临时文件
  （`Gin.MaxMultipartMemory` 同步为 8MB），不会整份读进内存；控制器侧通过 `ctx.MultipartForm()` 取文件
