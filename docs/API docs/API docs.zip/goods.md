# 商品管理 接口文档

## 接口概述

Goods 控制器负责积分商城功能，包含商品管理、订单管理、商品兑换购买、订单取消退款与确认收货。用户通过任务赚取积分（见 [Integral API 文档](integral.md)），再用积分兑换商品。

- **接口类型**: 业务接口 + 通用 CRUD（商品管理）

### 商品类型

| 类型值 | 名称 | 说明 |
| :--- | :--- | :--- |
| `virtual` | 虚拟商品 | 购买后立即自动发货 |
| `physical` | 实物商品 | 购买前需填写收货地址，管理员发货 |

### 虚拟商品发货方式

| 发货方式 | 名称 | 说明 |
| :--- | :--- | :--- |
| `text` | 文本内容 | 购买后直接展示预设的文本内容 |
| `card` | 卡密 | 购买后从卡密池随机发放一个卡密（抽取后自动移除） |

### 订单状态

| 状态值 | 名称 | 说明 |
| :--- | :--- | :--- |
| 0 | 待发货 | 实物商品等待管理员发货 |
| 1 | 已发货 | 管理员已发货（可附物流信息） |
| 2 | 已完成 | 订单完成（虚拟商品自动完成） |
| 3 | 已取消 | 用户/管理员取消，**积分已退还、库存与销量已回滚** |

### 兑换限制（商品维度）

| 字段 | 说明 |
| :--- | :--- |
| `limit_per_user` | 每人限购数量（0 = 不限购），按有效订单数统计（已取消订单不计入） |
| `min_exp` | 兑换所需最低经验值（0 = 不限），用于等级门槛 |
| `start_time` / `end_time` | 兑换时间窗口（0 = 不限），过期后不可兑换 |
| `sort` | 排序权重（越大越靠前，列表默认 `sort desc, id desc`） |

---

## 状态码规范

| 状态码 | 使用场景 |
| :--- | :--- |
| 200 | 接口调用成功且数据返回正常 |
| 202 | 业务处理失败但有特定原因（如积分不足、库存不足、卡密不足、已达限购） |
| 204 | 无数据 |
| 400 | 请求参数错误 |
| 401 | 未登录 |
| 403 | 无权限（非管理员） |

---

## 接口列表

### 1. 商品列表 [all]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/all`
- **说明**: 获取商品列表（公开接口，无需登录）。普通用户仅返回上架商品；管理员默认返回全部，可传 `status` 参数过滤。

> 非管理员查询会被强制附加 `deliver_type != "decoration"`（`app/api/controller/goods.go:399`）：
> **装扮商品不会出现在积分商城里**，装扮走 `/api/decoration/shop`。

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| page | int | 否 | 1 | 页码 |
| limit | int | 否 | 10 | 每页数量；受 `SYSTEM_PAGE_LIMIT` 限制（默认配置 `{Value:"1", Text:"50"}` → **最大 50**），传 `<=0` 会被改回 10 |
| order | string | 否 | sort desc, id desc | 排序，仅白名单生效，**非法值静默回退默认**（见下方白名单） |
| status | int | 否 | - | 商品状态过滤（仅管理员有效） |
| category | string | 否 | - | 分类筛选 |
| keyword | string | 否 | - | 商品名称关键词搜索 |

`order` 白名单（`app/api/controller/goods.go:47-53`，**大小写与逗号都必须一致**）：
`sort desc, id desc`、`sort asc, id desc`、`create_time desc`、`create_time asc`、
`price asc`、`price desc`、`stock desc`、`stock asc`、`sold desc`、`id desc`、`id asc`。

**响应体**：`{ data: [...], count: <总条数>, page: <总页数> }`。

> ⚠️ `page` 是**总页数**（`math.Ceil(count / limit)`），不是当前页码（`app/api/controller/goods.go:429`）。

**响应字段**（数组项）：

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | int | 商品 ID |
| title | string | 商品名称 |
| description | string | 商品描述 |
| cover | string | 商品封面 |
| price | int | 积分价格 |
| stock | int | 库存 |
| sold | int | 已兑换数量 |
| status | int | 状态（0下架 1上架） |
| type | string | 商品类型（virtual/physical） |
| deliver_type | string | 发货方式（`text` 文本 / `card` 卡密 / `decoration` 装扮 / `""` 无） |
| decoration_id | int | `deliver_type = "decoration"` 时关联的装扮 ID |
| decoration_name / decoration_type | string | 仅装扮商品附加，装扮名称与类型 |
| decoration_duration / decoration_permanent | int64 / bool | 仅装扮商品附加，有效期（秒）与是否永久 |
| category | string | 商品分类 |
| limit_per_user | int | 每人限购（0 = 不限） |
| min_exp | int | 兑换所需最低经验值（0 = 不限） |
| start_time / end_time | int64 | 兑换时间窗口（0 = 不限） |
| sort | int | 排序权重 |
| **can_buy** | bool | 当前登录用户是否可兑换（未登录时仅按商品维度判断） |
| **buy_reason** | string | 不可兑换原因（已售罄 / 未开始 / 已结束 / 需经验 N / 已达限购 / 积分不足） |
| **limit_remain** | int | 限购剩余数量（-1 = 不限购，0 = 已用完） |
| **my_bought** | int | 我已兑换数量（未登录恒为 0） |

> 注：`deliver_content`（文本发货内容）和 `cards`（卡密池）为敏感字段，仅管理员可见，普通用户查询不返回。

### 2. 商品详情 [one]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/one`
- **说明**: 获取单个商品详情（公开接口），同样会返回 `can_buy` / `buy_reason` / `limit_remain` / `my_bought`，详情页可直接据此渲染按钮。

> ⚠️ `one` 只接受 `id`（`goodsAllowQuerySlice = []any{"id"}`，`goods.go:44`），且**不校验 `status`**：
> 只要知道 id，非管理员也能读到已下架商品的详情（`all` / `count` 看不到）。
> 无数据返回 **204** `无数据！`。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | int | 是 | 商品 ID |

### 3. 商品分类 [categories]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/categories`
- **说明**: 聚合上架商品的分类及数量（公开接口），用于商城分类筛选栏。首个元素为「全部」。

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": [
    { "category": "", "name": "全部", "count": 12 },
    { "category": "coupon", "name": "coupon", "count": 5 },
    { "category": "vip", "name": "vip", "count": 3 }
  ]
}
```

> 可通过请求参数 `alias` 传入分类别名映射覆盖展示名（`alias={"vip":"会员"}`）。

### 4. 购买商品 [buy]

- **接口类型**: 业务接口
- **请求方式**: `POST`
- **请求地址**: `/api/goods/buy`
- **说明**: 使用积分兑换商品（需登录）。虚拟商品购买后立即发货；实物商品需先填写收货地址，购买后生成待发货订单。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| goods_id | int | 是 | 商品 ID |
| address | string | 否 | 收货地址 JSON 字符串（实物商品必填） |

**address 参数结构**（JSON 字符串）：

```json
{
  "name": "张三",
  "phone": "13800138000",
  "address": "广东省深圳市..."
}
```

**兑换前置校验**（在事务内依次执行，任一失败即回滚）：

1. 商品存在且为上架状态
2. 兑换时间窗口（`start_time` / `end_time`）
3. 实物商品必须有收货地址
4. 卡密商品卡密池非空
5. 经验门槛（`min_exp`）
6. 每人限购（`limit_per_user`，不含已取消订单）
7. 库存原子扣减（`stock > 0` 条件更新，防超卖）
8. 积分余额充足

**成功响应**:

```json
{
  "code": 200,
  "msg": "购买成功！",
  "data": {
    "order_id": 10,
    "order_no": "G2026091915302212345678",
    "price": 100,
    "integral": 25,
    "status": 2,
    "deliver_content": "这是一个卡密：ABCD-EFGH",
    "limit_remain": 1
  }
}
```

| 字段 | 说明 |
| :--- | :--- |
| order_id | 订单 ID |
| order_no | 订单号（唯一） |
| price | 消耗积分 |
| integral | 购买后剩余积分余额 |
| status | 订单状态（虚拟商品为 2 已完成，实物为 0 待发货） |
| deliver_content | 发货内容（虚拟商品：文本/卡密；实物商品为空） |
| limit_remain | 该商品限购剩余数量（-1 = 不限购） |

**失败响应**（202）：

| 状态码 | msg | 说明 |
| :--- | :--- | :--- |
| 202 | 商品不存在！ | 商品 ID 无效 |
| 202 | 商品已下架！ | 商品已下架 |
| 202 | 兑换尚未开始！ / 兑换活动已结束！ | 不在兑换时间窗口内 |
| 202 | 商品库存不足！ | 库存为 0 |
| 202 | 卡密库存不足！ | 卡密池为空 |
| 202 | 经验值达到 N 才可兑换！ | 未达经验门槛 |
| 202 | 已达每人限购上限！ | 超过限购数量 |
| 202 | 积分不足！ | 积分余额不够 |
| 202 | 请填写收货地址！ | 实物商品未填地址 |

### 5. 我的订单 [orders]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/orders`
- **说明**: 查询当前登录用户的订单列表（需登录，仅返回自己的订单）

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| page | int | 否 | 1 | 页码 |
| limit | int | 否 | 系统配置 | 每页数量 |
| status | int | 否 | - | 订单状态筛选（0/1/2/3） |
| goods_id | int | 否 | - | 按商品筛选 |

**响应字段**（数组项）：

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | int | 订单 ID |
| order_no | string | 订单号 |
| uid | int | 用户 ID |
| goods_id | int | 商品 ID |
| price | int | 成交积分价格 |
| status | int | 订单状态（0待发货 1已发货 2已完成 3已取消） |
| deliver_content | string | 发货内容（虚拟商品：文本/卡密） |
| logistics | string | 物流信息（实物商品发货后） |
| goods_title / goods_cover | string | 下单时的商品快照（商品改名后仍正确展示） |
| refund | int | 已退还积分（取消订单时） |
| cancel_time / finish_time | int64 | 取消时间 / 完成时间 |
| result.goods | object | 商品信息（id/title/cover/price/type/category，优先使用快照） |
| result.address | object | 收货地址（实物商品，含 name/phone/address） |
| create_time | int64 | 下单时间戳 |

### 6. 订单详情 [order-one]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/order-one`
- **说明**: 查询单个订单详情（需登录，仅本人或管理员）

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | int | 是 | 订单 ID |

**失败响应**:403 无权限（非本人且非管理员）、204 订单不存在

### 7. 取消订单 [cancel-order]

- **接口类型**: 业务接口
- **请求方式**: `PUT`
- **请求地址**: `/api/goods/cancel-order`
- **说明**: 取消订单并**原路退还积分**（需登录）。仅「待发货」（status = 0）订单可取消；虚拟商品下单即完成，不涉及取消。管理员可通过 `order-status` 取消任意订单。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | int | 是 | 订单 ID |

**事务内处理**：

1. 校验订单归属与状态（仅 status = 0）
2. 回滚库存 `stock + 1`
3. 回滚销量 `sold - 1`（不小于 0）
4. 退还积分 `integral + price`，写入 `refund` 类型积分流水（含 `balance_after` 快照）
5. 订单状态置为 3，记录 `refund` 与 `cancel_time`

**成功响应**:

```json
{
  "code": 200,
  "msg": "订单已取消，积分已退还！",
  "data": {
    "id": 10,
    "status": 3,
    "refund": 100,
    "integral": 125
  }
}
```

**失败响应**（202）：无权操作该订单！ / 订单已取消！ / 当前订单状态不可取消！

### 8. 确认收货 [receive]

- **接口类型**: 业务接口
- **请求方式**: `PUT`
- **请求地址**: `/api/goods/receive`
- **说明**: 用户把自己的「已发货」订单置为「已完成」（需登录）

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | int | 是 | 订单 ID |

**成功响应**:

```json
{
  "code": 200,
  "msg": "确认收货成功！",
  "data": { "id": 10, "status": 2 }
}
```

**失败响应**（202）：无权操作该订单！ / 当前订单状态不可确认收货！

### 9. 我的兑换统计 [my-stats]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/goods/my-stats`
- **说明**: 当前登录用户的兑换统计（需登录），用于商城页顶部数据条

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "order_total": 6,
    "pending": 1,
    "shipped": 1,
    "completed": 3,
    "canceled": 1,
    "integral_spent": 480,
    "integral": 125
  }
}
```

> `integral_spent` 只统计未取消订单消耗的积分。

### 10. 全部订单 [orders-all]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `GET`
- **请求地址**: `/api/goods/orders-all`
- **说明**: 查询全部订单（仅管理员），支持按用户、状态、商品过滤

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| uid | int | 否 | 按用户 ID 过滤 |
| status | int | 否 | 按订单状态过滤（0/1/2/3） |
| goods_id | int | 否 | 按商品 ID 过滤 |
| page | int | 否 | 页码 |
| limit | int | 否 | 每页数量 |

### 11. 更新订单状态 [order-status]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `PUT`
- **请求地址**: `/api/goods/order-status`
- **说明**: 更新订单状态（仅管理员），实物商品发货时可附带物流信息

**权限说明**:仅 root 用户（管理员）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | int | 是 | 订单 ID |
| status | int | 是 | 订单状态（0待发货 / 1已发货 / 2已完成 / 3已取消） |
| logistics | string | 否 | 物流信息（发货时填写） |

> `status = 3` 时会走取消流程：自动退还积分、回滚库存与销量，并写入 `refund` 积分流水。
> `status = 2` 时会自动写入 `finish_time`。

**成功响应**:

```json
{
  "code": 200,
  "msg": "更新成功！",
  "data": {
    "id": 10,
    "status": 1
  }
}
```

### 12. 商城统计 [stats]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `GET`
- **请求地址**: `/api/goods/stats`
- **说明**: 商城运营数据总览（仅管理员）

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "goods": { "total": 12, "on": 9, "off": 3, "stock_warn": 2 },
    "order": { "total": 36, "pending": 2, "shipped": 1, "completed": 30, "canceled": 3 },
    "integral": { "spent": 8600, "refund": 300, "net": 8300 }
  }
}
```

| 字段 | 说明 |
| :--- | :--- |
| goods.stock_warn | 上架且库存 ≤ 5 的商品数（库存预警） |
| integral.spent / refund / net | 累计消耗积分 / 累计退还积分 / 净消耗 |

### 13. 商品管理接口（管理员专用）

- **接口类型**: 商品管理接口（管理员专用）

以下接口均需 root 权限，用于商品增删改：

| HTTP | method | 路径 | 说明 |
| :--- | :--- | :--- | :--- |
| POST | `save` | `/api/goods/save` | 保存商品（有 `id` 更新，无则创建） |
| POST | `create` | `/api/goods/create` | 创建商品 |
| PUT | `update` | `/api/goods/update` | 更新商品 |
| PUT | `restore` | `/api/goods/restore` | 恢复软删除商品 |
| DELETE | `remove` | `/api/goods/remove` | 软删除商品 |
| DELETE | `delete` | `/api/goods/delete` | 彻底删除商品 |
| DELETE | `clear` | `/api/goods/clear` | 清空回收站 |

**商品字段**:

| 字段名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| title | string | 是 | 商品名称 |
| description | string | 否 | 商品描述 |
| cover | string | 否 | 封面图片 URL |
| price | int | 是 | 积分价格 |
| stock | int | 是 | 库存 |
| status | int | 否 | 状态（0下架 1上架，默认 1） |
| type | string | 否 | 商品类型（virtual/physical，默认 virtual） |
| deliver_type | string | 否 | 发货方式：`text` 文本 / `card` 卡密 / `decoration` 装扮 / `""` 无发货 |
| decoration_id | int | 否 | `deliver_type = "decoration"` 时必填，关联的装扮 ID |
| deliver_content | string | 否 | 文本发货内容（text 类型） |
| cards | string | 否 | 卡密池 JSON 数组（card 类型） |
| **category** | string | 否 | 商品分类（自由字符串，用于前台分组） |
| **limit_per_user** | int | 否 | 每人限购数量（0 = 不限购） |
| **min_exp** | int | 否 | 兑换所需最低经验值（0 = 不限） |
| **start_time** | int64 | 否 | 兑换开始时间戳（0 = 不限） |
| **end_time** | int64 | 否 | 兑换结束时间戳（0 = 不限） |
| **sort** | int | 否 | 排序权重（越大越靠前） |

**cards 字段示例**:

```json
["卡密1-ABC", "卡密2-DEF", "卡密3-GHI"]
```

---

## 特殊说明

### 购买流程

1. **虚拟商品**（text/card）：用户点击兑换 → 确认 → 立即发货 → 订单状态为「已完成」，发货内容展示在订单中。
2. **实物商品**：用户点击兑换 → 填写收货地址 → 生成「待发货」订单 → 管理员后台发货（可填物流）→「已发货」→ 用户确认收货 / 管理员置为「已完成」。
3. **装扮商品**（`deliver_type = "decoration"`）：同一事务内扣 `goods.price` 积分 →
   `GrantDecorationTx(tx, uid, decoration_id, "shop", 0, order.Id)` 发放装扮 → 生成订单
   （`app/model/goods.go:356-364`）。

> ⚠️ 装扮有**两条购买路径，不要混用**：
> - 装扮商城（前台「装扮」页）走 `POST /api/decoration/buy`，价格/库存/经验门槛取自装扮自身，
>   **不写 `goods` / `goods_order`**；
> - 只有把装扮作为「商品」售卖时才走 `POST /api/goods/buy` + `deliver_type = "decoration"`。
>
> 另外 `goods/all` 对非管理员强制排除 `deliver_type = "decoration"`（`goods.go:399`），
> 所以装扮商品不会出现在积分商城列表里。

### 取消与退款流程

```text
待发货(0) --用户取消/管理员取消--> 已取消(3)
              ├─ 库存 +1、销量 -1
              ├─ 积分原路退还（写 refund 流水）
              └─ 记录 refund / cancel_time
```

- 仅「待发货」订单可取消，避免虚拟商品已发货后被取消
- 取消操作全程在数据库事务中执行，避免出现「退了积分没回滚库存」的不一致

### 卡密发放机制

卡密商品购买时，从卡密池随机抽取一个卡密写入订单的 `deliver_content`，并将该卡密从池中移除（事务保证原子性），防止重复发放。卡密池为空时购买失败并回滚。

### 限购与门槛

- 限购统计口径：该用户对该商品的**未取消订单数**（`status != 3`）
- 经验门槛基于用户 `exp` 字段，与等级体系（`/api/level`）天然对应
- 列表接口已返回 `can_buy` / `buy_reason` / `limit_remain`，前端无需重复计算

### 权限规则（auth-rules）

`goods` 控制器各接口在 `app/model/auth-rules.go` 中登记，规则类型（type）说明：

| type | 含义 | 接口 |
| :--- | :--- | :--- |
| `common` | 公开接口，无需登录 | `all`、`one`、`categories`、`count` |
| `login` | 需登录（未登录由中间件拦 **401**） | `orders`、`order-one`、`my-stats`、`buy`、`cancel-order`、`receive` |
| `default` | 需权限点（控制器内 `meta.permit` 判 **403**） | `orders-all`、`stats`、`save`/`create`、`update`/`restore`、`order-status`、`remove`/`delete`/`clear` |

> 新增接口必须在 `createAuthRules()` 的 `goods` 分组中登记，否则中间件会走「默认」分支要求权限点，普通用户将直接收到 403。

### 安全机制

- `cards`（卡密池）和 `deliver_content`（文本发货内容）为敏感字段，仅管理员可见，普通用户查询商品时不返回，防止白嫖
- 购买走数据库事务，扣库存用原子条件更新（防超卖），扣积分校验余额
- 列表排序与积分明细排序均使用**白名单**校验，防止 SQL 注入
- 订单号由「时间 + 用户 + 随机数」生成并建立唯一索引，防止重复订单
