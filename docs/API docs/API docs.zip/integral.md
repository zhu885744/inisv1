# 积分管理 接口文档

## 接口概述

Integral 控制器负责用户积分管理。积分是独立于经验值（EXP）的货币体系，用户通过任务（签到、登录、发布内容等）赚取积分，并用积分在积分商城兑换商品。

- **接口类型**: 业务接口（无通用 CRUD）

### 积分规则

积分规则通过 `SYSTEM_INTEGRAL_RULES` 配置项进行管理，定义各任务可获得的积分及每日上限。以下为默认规则：

| 任务类型 | 名称 | 单次积分 | 每日限制次数 | 图标 | 说明 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `login` | 每日登录 | 2 | 1 | `bi-box-arrow-in-right` | 每日首次登录 |
| `article-create` | 发布文章 | 10 | 5 | `bi-file-earmark-text` | 发布文章（自动触发） |
| `comment` | 发表评论 | 2 | 10 | `bi-chat-dots` | 发表评论（自动触发） |
| `moments` | 发布动态 | 20 | 1 | `bi-lightning` | 发布动态（自动触发） |
| `share` | 分享内容 | 2 | 3 | `bi-share` | 分享文章/页面/动态（自动触发） |

> **每日签到不在这里配置**：签到已独立成模块，它的积分来自签到配置
> （`SYSTEM_CHECKIN_RULES` 基础奖励里的积分，见 [checkin.md](checkin.md)）。
> 任务列表里的签到项由后端 `model.IntegralTaskConfig()` 按签到配置动态注入，
> 并带 `source: "checkin"` 标记，**不写入** `SYSTEM_INTEGRAL_RULES`；
> 历史配置里残留的 `check-in` 会在启动迁移时自动清理（读取时也会被忽略）。

**配置方式**：管理员可通过配置 API 修改 `SYSTEM_INTEGRAL_RULES` 的 JSON 值来调整规则，修改后立即生效。

> 规则字段说明：`name` 名称、`value` 单次积分、`daily_limit` 每日上限（**`0` 表示不限制**，不再拦截）、`icon` 前端图标类名（可选，缺省返回 `bi-coin`）。

> **签到任务的特殊处理**：签到积分由签到模块的配置决定（`SYSTEM_CHECKIN_RULES` 的 `base` 奖励，
> 见 [checkin.md](checkin.md)）。规则列表与「今日任务进度」里 `check-in` 的 `value`
> 自动跟随签到配置中基础奖励的积分合计；是否完成以签到记录（`inis_checkin`）为准，
> 而不是积分流水条数。签到关闭（`enabled = 0`）时该条任务不会出现。

### 流水类型（type）

| type | 方向 | 说明 |
| :--- | :--- | :--- |
| `check-in` / `login` / `article-create` / `comment` / `moments` / `share` | 收入 | 任务奖励 |
| `give` | 收入/支出 | 管理员调整 |
| `buy` | 支出 | 积分商城兑换 |
| `refund` | 收入 | 订单取消退款返还 |
| `card` | 收入 | 卡密兑换积分 |

---

### 卡密数据模型（inis_integral_card）

| 字段 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | int | 主键，自增 |
| card | varchar(64) | 卡密（**唯一索引**，字符集剔除 `0/1/I/O`） |
| value | int | 积分面额 |
| status | tinyint | 状态：`0` 未使用（谁都能兑换）/ `1` 已使用（已兑换成积分）/ `2` 已发放（活动奖励发给某用户，只有本人能兑换） |
| batch | varchar(32) | 批次号 |
| expire_time | int64 | 过期时间戳（**0 表示永久有效**） |
| uid | int | 使用 / 被发放该卡密的用户ID |
| use_time | int64 | 使用（兑换）时间戳 |
| json | longtext | 已发放卡密会记录 `{ granted_at, source }`（发放时间与来源，如 `check-in`） |
| remark | varchar(255) | 备注 |
| create_time / update_time / delete_time | int64 | 公共字段（软删除） |

---

## 状态码规范

| 状态码 | 使用场景 |
| :--- | :--- |
| 200 | 接口调用成功且数据返回正常 |
| 202 | 业务逻辑处理完成但有特殊状态（如积分不足、已达上限） |
| 204 | 无数据 |
| 400 | 请求参数错误 |
| 401 | 未登录 |
| 403 | 无权限（非管理员） |
| 405 | 方法不存在 |

---

## 接口列表

### 1. 积分概览 [status]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/integral/status`
- **说明**: 查询当前登录用户的积分概览（余额 + 累计收支 + 今日收支），需登录

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "integral": 125,
    "total_income": 420,
    "total_expense": 295,
    "today_income": 25,
    "today_expense": 100
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| integral | int | 当前积分余额 |
| total_income | int | 累计获得积分 |
| total_expense | int | 累计消耗积分 |
| today_income | int | 今日获得积分 |
| today_expense | int | 今日消耗积分 |

> 兼容说明：早期版本仅返回 `integral`，本次升级为向后兼容的字段扩展。

### 2. 积分明细 [all]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/integral/all`
- **说明**: 查询当前登录用户的积分流水（需登录，仅返回自己的），支持多条件筛选并返回区间收支合计

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| page | int | 否 | 1 | 页码 |
| limit | int | 否 | 系统配置 | 每页数量 |
| order | string | 否 | create_time desc | 排序（白名单：create_time desc/asc、value desc/asc、id desc/asc） |
| type | string | 否 | - | 流水类型：check-in / login / article-create / comment / moments / share / buy / refund / give |
| direction | string | 否 | - | 收支方向：`income` 只看收入 / `expense` 只看支出 |
| start | int64 | 否 | - | 起始时间戳（秒） |
| end | int64 | 否 | - | 结束时间戳（秒） |
| keyword | string | 否 | - | 描述关键词（模糊匹配） |

**成功响应**:

```json
{
  "code": 200,
  "msg": "数据请求成功！",
  "data": {
    "data": [
      {
        "id": 12,
        "uid": 1,
        "value": -100,
        "type": "buy",
        "description": "兑换商品：会员月卡",
        "json": { "goods_id": 3, "balance_after": 125 },
        "create_time": 1750982400
      }
    ],
    "count": 1,
    "page": 1,
    "summary": {
      "income": 0,
      "expense": 100,
      "net": -100
    }
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| data[].value | int | 积分变动值（正=获得，负=消耗） |
| data[].json.balance_after | int | 变动后余额快照（便于对账） |
| summary.income | int | 当前筛选条件下收入合计 |
| summary.expense | int | 当前筛选条件下支出合计 |
| summary.net | int | 净变动（收入 - 支出） |

### 3. 今日任务进度 [tasks]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/integral/tasks`
- **说明**: 查询当前登录用户的今日任务完成情况（需登录），用于「做任务赚积分」面板

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "list": [
      {
        "type": "check-in",
        "name": "每日签到",
        "icon": "bi-calendar-check",
        "value": 5,
        "daily_limit": 1,
        "today_count": 1,
        "today_income": 5,
        "progress": 100,
        "done": true,
        "remain": 0
      },
      {
        "type": "comment",
        "name": "发表评论",
        "icon": "bi-chat-dots",
        "value": 2,
        "daily_limit": 10,
        "today_count": 3,
        "today_income": 6,
        "progress": 30,
        "done": false,
        "remain": 14
      }
    ],
    "today_income": 11,
    "done_count": 1,
    "total_count": 6,
    "streak": 4
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| list[].today_count | int | 今日已获得该奖励的次数 |
| list[].today_income | int | 今日该任务已获得积分 |
| list[].progress | int | 进度百分比（不限制的任务固定 100） |
| list[].done | bool | 今日是否已达上限 |
| list[].remain | int | 还能获得的积分（用于「还可 +N」提示） |
| today_income | int | 今日获得积分合计 |
| done_count / total_count | int | 已完成任务数 / 任务总数 |
| streak | int | 连续签到天数 |

### 4. 积分排行榜 [rank]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/integral/rank`
- **说明**: 公开接口，无需登录。返回积分排行榜与当前登录用户的排名（未登录时 `my_rank`、`my_value` 为 0）

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| by | string | 否 | earned | `earned` 累计获得榜 / `balance` 当前余额榜 |
| limit | int | 否 | 20 | 返回条数（最大 100） |

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "by": "earned",
    "list": [
      {
        "rank": 1,
        "id": 3,
        "nickname": "张三",
        "avatar": "https://...",
        "description": "这个人很懒",
        "title": "掌门",
        "value": 1280,
        "is_me": false
      }
    ],
    "my_rank": 12,
    "my_value": 420
  }
}
```

### 5. 积分任务规则 [rules]

- **接口类型**: 业务接口
- **请求方式**: `GET`
- **请求地址**: `/api/integral/rules`
- **说明**: 获取积分任务规则列表（公共接口，无需登录），返回各行为可获得的积分及每日上限

**响应字段**（数组项）：

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| type | string | 任务类型（check-in/login/article-create 等） |
| name | string | 任务名称 |
| value | int | 单次获得的积分 |
| daily_limit | int | 每日限制次数（0 表示不限制） |
| icon | string | 前端图标类名（如 `bi-calendar-check`） |
| source | string | 仅签到项返回 `checkin`：表示该条来自签到配置，管理端不应对它编辑/保存 |

> 顺序固定（签到置顶，其余按类型升序），管理端渲染规则表时请跳过 `source = checkin` 的那条。

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": [
    { "type": "check-in", "name": "每日签到", "value": 5, "daily_limit": 1, "icon": "bi-calendar-check", "source": "checkin" },
    { "type": "login", "name": "每日登录", "value": 2, "daily_limit": 1, "icon": "bi-box-arrow-in-right" }
  ]
}
```

### 6. 调整积分 [give]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `POST`
- **请求地址**: `/api/integral/give`
- **说明**: 管理员手动给指定用户增加或扣除积分，不受每日规则限制，直接修改用户积分余额。**支持单个（`uid`）与批量（`uids`）两种方式**。

**权限说明**:仅 root 用户（管理员）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| uid | int | 二选一 | 目标用户ID（单个） |
| uids | array | 二选一 | 目标用户ID数组（批量，优先于 uid） |
| value | int | 是 | 积分数量（正数为增加，负数为扣除，不能为0） |
| description | string | 否 | 操作描述 |

**单个用户响应**:

```json
{
  "code": 200,
  "msg": "调整成功！",
  "data": {
    "uid": 1,
    "value": 100,
    "integral": 225
  }
}
```

**批量发放响应**（逐个处理，失败不影响其它用户）：

```json
{
  "code": 200,
  "msg": "批量调整完成！",
  "data": {
    "total": 3,
    "success": 2,
    "failed": 1,
    "list": [
      { "uid": 1, "success": true, "msg": "成功", "balance": 225 },
      { "uid": 2, "success": true, "msg": "成功", "balance": 100 },
      { "uid": 999, "success": false, "msg": "用户不存在", "balance": 0 }
    ]
  }
}
```

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | 参数错误（uid/uids 为空、value 为0） |
| 403 | 无权限（非管理员调用） |
| 202 | 业务失败（如扣减时积分不足） |

> 说明：管理员调整积分成功后，系统会向目标用户发送一条 `system`（系统通知）类型的消息通知（增加/扣除各一条），详见 [Notification API 文档](notification.md)。

### 7. 生成卡密 [card-generate]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `POST`
- **请求地址**: `/api/integral/card-generate`
- **说明**: 管理员批量生成积分卡密，用户可凭卡密自助兑换积分。卡密使用密码学安全随机数生成，字符集剔除易混淆字符（`0/1/I/O`），默认长度 16 位。

**权限说明**:仅管理员（`root` 权限点）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| value | int | 是 | - | 积分面额（1 ~ 1000000） |
| count | int | 否 | 1 | 生成数量（1 ~ 1000） |
| length | int | 否 | 16 | 卡密长度（**不小于 8**，最大 64） |
| expire_time | int64 | 否 | 0 | 卡密有效期（秒级时间戳，**0 表示永久有效**） |
| expire | string | 否 | - | 卡密有效期（日期字符串，支持 `2006-01-02` 或 `2006-01-02 15:04:05`；仅日期时到当天 23:59:59 失效）。与 `expire_time` 二选一，`expire_time` 优先 |
| remark | string | 否 | - | 备注（便于按批次管理） |

**成功响应**:

```json
{
  "code": 200,
  "msg": "生成成功！",
  "data": {
    "batch": "20260920153012ABCDEF",
    "count": 2,
    "value": 100,
    "expire_time": 1798905599,
    "cards": ["2K7M9PQ4XZAH3TUV", "B4WX8YRJ2M6NPQST"],
    "list": [
      { "id": 1, "card": "2K7M9PQ4XZAH3TUV", "value": 100, "status": 0, "batch": "20260920153012ABCDEF", "expire_time": 1798905599, "uid": 0, "use_time": 0 }
    ]
  }
}
```

> 安全提示：`cards` 为卡密明文，仅在本接口返回一次，请管理员妥善保管并自行导出下发。

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | 参数错误（面额为0/超限、数量超限、长度小于 8、有效期早于当前时间或格式错误） |
| 403 | 无权限（非管理员调用） |

### 8. 导入自定义卡密 [card-import]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `POST`
- **请求地址**: `/api/integral/card-import`
- **说明**: **卡密内容由管理员自己填写**（一行一个），而不是系统随机生成 —— 适用于「卡密来自其它系统 / 自己印制 / 指定编号」的场景；导入后的卡密与随机生成的完全等价（同一张表、同样的兑换流程）。

**与生成卡密的区别**：`card-generate` 只能给「数量 + 长度」，卡密由系统随机产生；`card-import` 直接写入管理员提供的卡密明文。

**权限说明**:仅管理员（`root` 权限点）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| codes | array / string | 是 | - | 卡密内容：数组，或一行一个的整段文本（也支持英文/中文逗号、分号分隔） |
| value | int | 是 | - | 积分面额（1 ~ 1000000，本批次统一面额） |
| expire_time | int64 | 否 | 0 | 卡密有效期（秒级时间戳，**0 表示永久有效**） |
| expire | string | 否 | - | 卡密有效期（日期字符串，规则同 `card-generate`） |
| remark | string | 否 | - | 备注（便于按批次管理） |

**处理规则**：

1. **标准化**：每个卡密都按兑换接口的同一套规则处理 —— 去掉空格与连字符、转成大写。因此管理员填 `sn-0001-aaaa`、用户兑 `SN 0001 AAAA` 都能命中同一张卡。
2. **格式校验**：长度必须是 **8 ~ 64 位**（与 `card-redeem` 一致），空行忽略。
3. **重复跳过**：本次内容里重复的、以及系统里已存在的卡密会被**跳过**（不会报错中断），并在响应 `report.skipped` 里列出原因；注意**回收站里的卡密同样占用卡号**（唯一索引不因软删除释放）。
4. **上限**：单次最多 1000 张，超出请分批导入。
5. **全空保护**：如果本次没有任何卡密能导入（全部重复或格式不合法），返回 400 且带上 `report`，避免管理员误以为导入成功。

**成功响应**:

```json
{
  "code": 200,
  "msg": "导入成功！",
  "data": {
    "batch": "20261001102030GHJKLM",
    "count": 3,
    "value": 100,
    "expire_time": 0,
    "cards": ["SN2026000001", "SN2026000002", "SN2026000003"],
    "report": {
      "total": 5,
      "success": 3,
      "skipped_count": 2,
      "truncated": false,
      "skipped": [
        { "code": "SN2026000001", "reason": "本次导入内容里重复" },
        { "code": "OLD0000001", "reason": "系统里已存在相同卡密" }
      ]
    },
    "list": [
      { "id": 11, "card": "SN2026000001", "value": 100, "status": 0, "batch": "20261001102030GHJKLM", "expire_time": 0, "uid": 0, "use_time": 0 }
    ]
  }
}
```

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | 参数错误（面额为 0/超限、卡密全部重复或格式不合法、超过单次 1000 张、有效期早于当前时间） |
| 403 | 无权限（非管理员调用） |

**后台入口**：后台「积分 → 积分卡密 → 自定义导入」（`Mellow/src/views/admin/Integral.vue`）。

### 9. 卡密兑换积分 [card-redeem]

- **接口类型**: 业务接口 / 需登录
- **请求方式**: `POST`
- **请求地址**: `/api/integral/card-redeem`
- **说明**: 登录用户凭卡密兑换积分，兑换成功后积分立即到账并写入 `card` 类型流水。同一张卡密在并发场景下仅能被兑换一次（数据库条件更新 + 影响行数校验）。

> 卡密分两种可兑换状态：`0 未使用`（任何人凭卡密都能兑换）与 `2 已发放`（活动奖励，**只有绑定用户**能兑换，其它人兑换会得到「卡密已被使用！」）。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| card | string | 是 | 卡密（自动忽略空格/连字符并转为大写，容错输入） |

**成功响应**:

```json
{
  "code": 200,
  "msg": "兑换成功！",
  "data": {
    "card_id": 1,
    "value": 100,
    "batch": "20260920153012ABCDEF",
    "integral": 325
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| card_id | int | 卡密记录ID |
| value | int | 本次兑换的积分面额 |
| batch | string | 所属批次号 |
| integral | int | 兑换后的积分余额 |

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | `card` 为空 |
| 401 | 未登录 |
| 429 | 失败次数过多，临时锁定（默认连续失败 10 次锁定 10 分钟，防暴力枚举） |
| 202 | 业务失败（卡密不存在 / 已被使用 / 已过期 / 格式不正确） |

### 10. 设置卡密兑换人 [card-bind]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `POST`
- **请求地址**: `/api/integral/card-bind`
- **说明**: 把**已有卡密**手动绑定给指定用户（设置兑换人），支持一次传多张；也可以解除绑定。

适用于「线下发奖 / 定向发放」这类先批量生成、之后再指定给谁的场景。

- `uid > 0`：把「未使用」的卡密置为「已发放」并绑定该用户；已是「已发放」的卡密会**改绑**（覆盖原 uid）
- `uid = 0`：**解除绑定** —— 「已发放」的卡密退回「未使用」（清空 uid 与使用时间）
- **已兑换**（`status=1`）的卡密会被跳过：积分流水已经落库，改 uid 会让卡密归属与流水对不上账
- 并发安全：逐张做「状态条件更新 + 影响行数判断」，被并发兑换走的那张自动跳过

**权限**：需要权限点「设置卡密兑换人」（`path=card-bind&type=default`，见 `auth-rules` 的 `integral` 节点）。

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| ids | array / string | 是 | 卡密记录 ID，数组或以逗号分隔的字符串 |
| uid | int | 是 | 目标用户 ID；传 `0` 表示解除绑定 |

**成功响应**:

```json
{
  "code": 200,
  "msg": "操作成功！共 2 张卡密。",
  "data": {
    "list": [
      { "id": 12, "card": "AB3D5F7H9K2M4P6R", "value": 100, "prev_uid": 0, "expire_time": 0 }
    ],
    "count": 2,
    "skipped": 0,
    "uid": 7
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| list | array | 实际生效的卡密明细（含明文、面额、改绑前的 `prev_uid`） |
| count | int | 生效条数 |
| skipped | int | 因「已兑换」被跳过的条数 |
| uid | int | 本次操作的目标用户（`0` 表示解绑） |

**副作用**：绑定成功后会给目标用户发一条**站内信**（类型 `system`，`bind_type=integral-card`，
消息中心点击可到「我的积分 → 卡密兑换」），内容包含卡密明文（最多列 5 张，其余概括为「等 N 张」）；
**解除绑定不会打扰用户**。

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | `ids` 为空 / 目标用户不存在 |
| 403 | 缺少权限点「设置卡密兑换人」 |
| 202 | 没有可操作的卡密（选中的都已兑换，或解绑时都没绑定用户） |

### 11. 卡密列表 [card-all]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `GET`
- **请求地址**: `/api/integral/card-all`

**权限说明**:仅管理员（`root` 权限点）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| page | int | 否 | 1 | 页码 |
| limit | int | 否 | 系统配置 | 每页数量 |
| order | string | 否 | id desc | 排序（白名单：id、value、create_time、use_time 的 asc/desc） |
| status | int | 否 | - | 状态：0 未使用 / 1 已使用 |
| batch | string | 否 | - | 批次号 |
| uid | int | 否 | - | 使用该卡密的用户ID |
| value | int | 否 | - | 积分面额 |
| keyword | string | 否 | - | 卡密模糊搜索 |
| expired | int | 否 | - | 1 仅已过期 / 0 仅未过期（含永久） |
| field | string/array | 否 | - | 字段过滤 |

**成功响应**:

```json
{
  "code": 200,
  "msg": "数据请求成功！",
  "data": {
    "data": [
      {
        "id": 1, "card": "2K7M9PQ4XZAH3TUV", "value": 100, "status": 1,
        "batch": "20260920153012ABCDEF", "expire_time": 0,
        "uid": 3, "nickname": "张三", "use_time": 1798905600, "create_time": 1798800000
      }
    ],
    "count": 1,
    "page": 1
  }
}
```

> 说明：列表项中的 `nickname` 为使用者昵称（后端一次性批量补充，未使用的卡密为空字符串），管理端应优先展示昵称而非 `uid`。

### 12. 卡密统计 [card-stats]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `GET`
- **请求地址**: `/api/integral/card-stats`

**权限说明**:仅管理员（`root` 权限点）可调用

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": {
    "total": 100,
    "unused": 80,
    "used": 20,
    "expired": 5,
    "value_total": 10000,
    "value_used": 2000
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| total | int | 卡密总数 |
| unused | int | 未使用且未过期数量（**可用库存**） |
| granted | int | 已发放给用户、待其兑换的数量 |
| used | int | 已使用数量 |
| expired | int | 已过期未使用数量 |
| value_total | int | 累计发放积分面额 |
| value_used | int | 累计已兑换积分 |

### 13. 删除卡密 [card-remove]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `DELETE`
- **请求地址**: `/api/integral/card-remove`（软删除）、`/api/integral/card-delete`（彻底删除）

**权限说明**:仅管理员（`root` 权限点）可调用

**请求参数**:

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| ids | array/string | 是 | 卡密ID列表，支持数组或在字符串中用任意分隔符（后端正则提取数字） |

> **已发放（`status = 2`）的卡密不能删除**：这类卡密是活动（如签到）奖励，
> 已绑定到某个用户，删掉用户就找不回自己的奖励。提交时会自动跳过，
> 响应里用 `skipped` 告知跳过数量；全部都是已发放时返回 202「已发放给用户的卡密不能删除！」。

**成功响应**:

```json
{ "code": 200, "msg": "删除成功！1 张已发放给用户的卡密已跳过。", "data": { "ids": [1, 2], "skipped": 1 } }
```

### 14. 导出未使用卡密 [card-export]

- **接口类型**: 业务接口 / 管理员专用
- **请求方式**: `GET`
- **请求地址**: `/api/integral/card-export`
- **说明**: 导出全部「**未使用且未过期**」的卡密明文，用于管理端批量复制 / 下发。单次最多导出 10000 张，超出部分不会返回，并通过 `truncated` 标记。

**权限说明**:仅管理员（`root` 权限点）可调用

> 安全提示：该接口返回卡密明文，属敏感操作，后端会记录操作日志（操作人、导出数量、是否截断）以便审计。

**请求参数**（均为可选，用于按条件筛选导出范围）：

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| batch | string | 否 | 仅导出指定批次 |
| value | int | 否 | 仅导出指定积分面额 |
| keyword | string | 否 | 卡密模糊匹配 |

**成功响应**:

```json
{
  "code": 200,
  "msg": "导出成功！",
  "data": {
    "count": 2,
    "truncated": false,
    "cards": ["2K7M9PQ4XZAH3TUV", "B4WX8YRJ2M6NPQST"]
  }
}
```

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| count | int | 本次导出的卡密数量 |
| truncated | bool | 是否因超出单次上限（10000）而被截断 |
| cards | array | 卡密明文列表（未使用且未过期） |

**失败响应**:

| 状态码 | 说明 |
| :--- | :--- |
| 400 | 导出失败（数据库异常等） |
| 403 | 无权限（非管理员调用） |

### 15. 我的待兑换卡密 [card-mine]

- **接口类型**: 业务接口 / 需登录
- **请求方式**: `GET`
- **请求地址**: `/api/integral/card-mine`
- **说明**: 返回发放给自己、尚未兑换的卡密（`status = 2 已发放`）。

签到等活动把卡密直接发到用户账号里，用户可能没留意消息中心，
这里让他在「我的积分 → 卡密兑换」随时找回，并支持一键兑换（逐张调 `card-redeem` 即可）。

**请求参数**:

| 参数名 | 类型 | 必填 | 默认 | 说明 |
| :--- | :--- | :--- | :--- | :--- |
| limit | int | 否 | 10 | 条数（最大 100） |

**响应字段**（数组项）：

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| card_id | int | 卡密记录ID |
| card | string | 卡密明文（属于自己，可直接兑换） |
| value | int | 面额（兑换后得到的积分） |
| batch | string | 批次号 |
| expire_time | int64 | 过期时间戳（0 表示永久有效） |
| expired | bool | 是否已过期 |
| granted_at | int64 | 发放时间戳（来自卡密的 `json` 字段） |
| source | string | 来源类型，如 `check-in`（签到） |
| remark | string | 备注 |

**成功响应**:

```json
{
  "code": 200,
  "msg": "查询成功！",
  "data": [
    {
      "card_id": 12,
      "card": "K7M9X2P7Q1Z8B4N6",
      "value": 50,
      "batch": "20260927153000AB12CD",
      "expire_time": 0,
      "expired": false,
      "granted_at": 1790426827,
      "source": "check-in",
      "remark": ""
    }
  ]
}
```

---

## 特殊说明

### 积分获取方式

积分通过以下行为自动获得（均由后端在对应业务触发点自动发放）：

| 行为 | 触发位置 | 积分类型 |
| :--- | :--- | :--- |
| 签到 | `checkin.go` `sign`（签到模块的奖励引擎发放） | `check-in` |
| 登录 | `comm.go` `loginExp` | `login` |
| 发布文章 | `article.go` `create` | `article-create` |
| 发表评论 | `comment.go` `create` | `comment` |
| 发布动态 | `moments.go` `create` | `moments` |
| 分享内容 | `exp.go` `share` | `share`（可扩展） |
| 卡密兑换 | `integral.go` `cardRedeem` | `card` |

### 积分消耗方式

积分通过在积分商城兑换商品消耗（详见 [Goods API 文档](goods.md)）：
- 购买时由 `Goods.Buy` 在**事务**中扣减积分并写入 `buy` 类型流水
- 取消订单时由 `GoodsOrder.CancelOrder` 在事务中退还积分并写入 `refund` 类型流水

### 积分变动通知

管理员通过 `give` 接口增加/扣除用户积分成功后，系统会调用 `model.IntegralGiveNotify` 向目标用户发送一条消息通知（增加/扣除各对应一个标题）。该通知**归入系统通知（`type=system`）**，不单独占用通知类型。**积分变动通知仅此一个触发场景**，任务奖励、商城消耗、卡密兑换等其它积分变动均不发送通知。

### 卡密安全机制

- 卡密使用 `crypto/rand`（密码学安全随机数）生成，默认 16 位、字符集 32 个（剔除易混淆字符），单卡熵约 80 bit，无法被枚举猜测；
- 卡密字段带**唯一索引**，从数据库层面防止重复；
- 兑换接口需登录，并通过「状态条件更新 + 影响行数判断」保证同一张卡密并发下只被兑换一次；
- 兑换失败累计达 10 次将锁定 10 分钟（基于缓存），防止暴力枚举；
- 卡密明文仅在生成接口返回一次，积分流水中记录的是脱敏后的卡密。

### 每日上限规则

- `daily_limit > 0`：当日该类型奖励次数达到上限后，`Add` 返回「今日奖励已达上限！」
- `daily_limit = 0`：不限制次数（升级前 `0` 会被误判为「已达上限」，现已修复）

### 权限控制

- 普通用户只能查询自己的积分余额、明细、任务进度
- 排行榜与任务规则为公开接口
- 只有管理员可以调整用户积分（`give`）、生成/导入/查询/删除卡密（`card-generate`/`card-import`/`card-all`/`card-stats`/`card-remove`/`card-delete`）
- 登录用户可凭卡密自助兑换积分（`card-redeem`），并查看自己的待兑换卡密（`card-mine`）

### 权限规则（auth-rules）

`integral` 控制器各接口在 `app/model/auth-rules.go` 中登记，规则类型（type）说明：

| type | 含义 | 接口 |
| :--- | :--- | :--- |
| `common` | 公开接口，无需登录 | `rules`、`rank` |
| `login` | 需登录 | `status`、`all`、`tasks`、`card-redeem` |
| `root` | 需管理员权限点 | `give`、`card-generate`、`card-import`、`card-all`、`card-stats`、`card-export`、`card-remove`、`card-delete` |

> 新增接口必须在 `createAuthRules()` 的 `integral`/`goods` 分组中登记，否则中间件会走「默认」分支要求权限点，普通用户将直接收到 403。
